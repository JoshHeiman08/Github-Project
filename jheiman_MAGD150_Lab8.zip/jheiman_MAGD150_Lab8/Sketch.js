var img;
var gif;

function preload() {

   gif1 = createImg("Winter_Landscape.gif");
   gif2 = createImg("Bird.gif");

}

function setup(){
createCanvas(800, 500);
colorMode(RGB, 255, 255, 255, 1);

}

function draw(){
  background(100);

  gif1.position(30, 30);
  gif1.size(750, 420);
  fill(255);
  gif2.position(mouseX,mouseY );
  gif2.size(80, 80);
  
  if (mouseY > 25 && mouseY < 405 && mouseX > 25 && mouseX < 705){
    gif2.position(mouseX,mouseY );
  } else{
    gif2.position(20 - mouseX,20 - mouseY );
  }
  

let brand = 'Samsung';
fill(250);
stroke(0);
strokeWeight(2);
textSize(25);
textFont('Helvetica');
text(brand, 350, 460, 200, 200);

let tdesc = 'This game title would be called "Migrated Alaska"';
textSize(12);
text(tdesc, 100, 453, 100, 100);

let power = 'Power'
textSize(16);
fill(220, 0, 0, 1);
stroke(150, 0, 150, 1);
strokeWeight(1);
textFont('OriginTech');
text(power, 700, 480, 200, 200);
}
