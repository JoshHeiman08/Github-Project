let mcoordx = 0;
let mcoordy = 0;
let pmcoordx = 0;
let pmcoordy = 0;
let framerate = 0;
let negframerate = 0;

function setup() {
  // put setup code here
  createCanvas(600, 400);
  background(56)
  let framerate = 60;
  frameRate(framerate);
}

function draw() {
  // put drawing code here
colorMode(RGB, 255, 255, 255, 1);
  let mcoordx = mouseX;
  let mcoordy = mouseY;
  let pmcoordx = pmouseX;
  let pmcoordy = pmouseY;
fill(0, 210, 20, 1);
noStroke();

  if(mcoordx > 300 && mcoordy > 200)
  {
  ellipse(mcoordx,mcoordy, 25, 25);
  strokeWeight(2);
  stroke(200, 0, 70, 1);
    line(mcoordx, mcoordy, pmcoordx, pmcoordy);
  print(pmcoordx + ' -> ' + mcoordx);
  }

noStroke();
  if(mcoordx < 300 && mcoordy < 200)
  {
    fill(100, 0, 200, 1);
    ellipse(mcoordx, mcoordy, 10, 10);
    framerate = 90;
    frameRate(framerate);
  }


  if(mcoordx > 300 && mcoordy < 200)
  {
    fill(240, 200, 0, 1);
    ellipse(mcoordx, mcoordy, 15, 15);
    let framerate = abs(-10);
    frameRate(framerate);
  }

  if(mcoordx < 300 && mcoordy > 200)
  {
    fill(240, 0, 50, 1);
    ellipse(mcoordx, mcoordy, 20, 20);
   let framerate = sqrt(1600);
    frameRate(framerate);
  }

  if (pmcoordy > 200 && pmcoordx < 600)
  {
    fill(0, 0, 0, 1);
    rect(250, 180, 80, 80);
  }
  else
     rect(250, 180, 80, 80);

}
